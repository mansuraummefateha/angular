﻿namespace ng_MasterDetails.ViewModels
{
    public class ImagePathResponse
    {
        public string PictureName { get; set; } = default!;
    }
}
